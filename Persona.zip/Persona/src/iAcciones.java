
public interface iAcciones {
    public void guardar();
    public void imprimir();
    public void limpiar();
}
